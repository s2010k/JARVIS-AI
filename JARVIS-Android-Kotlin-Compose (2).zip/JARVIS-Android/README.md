# JARVIS — Native Android Assistant (Kotlin & Jetpack Compose)

Version 1 native Android voice and command assistant built with Kotlin, Jetpack Compose, Material 3, Android `SpeechRecognizer`, and `TextToSpeech`.

## Features
- **Holographic Arc Reactor Core**: Custom Jetpack Compose `Canvas` animation with pulsing rings, rotating arcs, and radial sound-wave bars reactive to speech amplitude (`onRmsChanged`) and assistant state.
- **Push-to-Talk Voice Engine**: Single-shot `SpeechRecognizer` listening (never records continuously in the background) with `RECORD_AUDIO` runtime permission handling and graceful fallback to text input.
- **English & Hindi Support**: Switch between `en-US` and `hi-IN` for both speech recognition and `TextToSpeech` spoken responses.
- **Local Command Intelligence**: Offline command handler in `JarvisCommandHandler.kt` for greetings, current time, current date, system status, help, and conversation clearing.
- **Local Persistence**: Conversation history and user preferences saved locally on-device via `SharedPreferences` (`JarvisStorage.kt`).

## Project Structure
- `app/src/main/java/com/jarvis/assistant/MainActivity.kt` — Activity host and `RECORD_AUDIO` permission launcher
- `app/src/main/java/com/jarvis/assistant/viewmodel/JarvisViewModel.kt` — UI state coordination
- `app/src/main/java/com/jarvis/assistant/voice/VoiceEngine.kt` — `SpeechRecognizer` & `TextToSpeech` wrapper
- `app/src/main/java/com/jarvis/assistant/intelligence/JarvisCommandHandler.kt` — Local command parser
- `app/src/main/java/com/jarvis/assistant/data/JarvisStorage.kt` — Local device storage
- `app/src/main/java/com/jarvis/assistant/ui/JarvisHomeScreen.kt` — Main Compose interface
- `app/src/main/java/com/jarvis/assistant/ui/components/ArcReactorCore.kt` — Animated circular AI core
- `app/src/main/java/com/jarvis/assistant/ui/components/SettingsDialog.kt` — Preferences modal
