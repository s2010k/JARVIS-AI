package com.jarvis.assistant

import com.jarvis.assistant.intelligence.JarvisCommandHandler
import com.jarvis.assistant.model.JarvisLanguage
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.ZoneId
import java.time.ZonedDateTime

class JarvisCommandHandlerTest {

    private val handler = JarvisCommandHandler()
    private val fixedTime = ZonedDateTime.of(2026, 11, 23, 19, 18, 0, 0, ZoneId.of("UTC"))

    @Test
    fun helloJarvisReturnsExpectedGreeting() {
        val result = handler.processCommand("Hello Jarvis", JarvisLanguage.ENGLISH, fixedTime)
        assertEquals("Hello. How can I help?", result.reply)
    }

    @Test
    fun whatTimeIsItSpeaksCurrentTime() {
        val result = handler.processCommand("What time is it?", JarvisLanguage.ENGLISH, fixedTime)
        assertEquals("The current time is 7:18 PM.", result.reply)
    }

    @Test
    fun whatIsTodaysDateSpeaksDate() {
        val result = handler.processCommand("What is today's date?", JarvisLanguage.ENGLISH, fixedTime)
        assertEquals("Today's date is Monday, November 23, 2026.", result.reply)
    }

    @Test
    fun unknownCommandReturnsHelpfulReply() {
        val result = handler.processCommand("Launch satellites", JarvisLanguage.ENGLISH, fixedTime)
        assertTrue(result.reply.contains("Launch satellites"))
        assertTrue(result.reply.contains("What time is it?"))
    }

    @Test
    fun hindiGreetingReturnsHindiResponse() {
        val result = handler.processCommand("नमस्ते जार्विस", JarvisLanguage.HINDI, fixedTime)
        assertEquals("नमस्ते। मैं आपकी क्या सहायता कर सकता हूँ?", result.reply)
    }
}
