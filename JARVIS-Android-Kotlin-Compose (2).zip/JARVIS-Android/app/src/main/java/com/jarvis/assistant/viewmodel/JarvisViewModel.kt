package com.jarvis.assistant.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.jarvis.assistant.data.JarvisStorage
import com.jarvis.assistant.intelligence.JarvisCommandHandler
import com.jarvis.assistant.model.AssistantState
import com.jarvis.assistant.model.ChatMessage
import com.jarvis.assistant.model.JarvisLanguage
import com.jarvis.assistant.model.JarvisUiState
import com.jarvis.assistant.model.MessageSender
import com.jarvis.assistant.voice.VoiceEngine
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class JarvisViewModel(application: Application) : AndroidViewModel(application) {

    private val storage = JarvisStorage(application)
    private val commandHandler = JarvisCommandHandler()
    private var thinkingJob: Job? = null

    private val _uiState = MutableStateFlow(
        JarvisUiState(
            settings = storage.loadSettings(),
            messages = storage.loadMessages()
        )
    )
    val uiState: StateFlow<JarvisUiState> = _uiState.asStateFlow()

    private val voiceEngine = VoiceEngine(
        context = application,
        onListeningStarted = {
            _uiState.update {
                it.copy(
                    assistantState = AssistantState.LISTENING,
                    statusDetail = "Listening (${it.settings.language.displayName})",
                    partialTranscript = "",
                    errorMessage = null
                )
            }
        },
        onPartialResult = { partial ->
            _uiState.update { it.copy(partialTranscript = partial) }
        },
        onFinalResult = { transcript ->
            _uiState.update { it.copy(partialTranscript = "") }
            submitUserCommand(transcript)
        },
        onRmsChanged = { rms ->
            _uiState.update { it.copy(rmsDb = rms) }
        },
        onSpeechError = { message ->
            _uiState.update {
                it.copy(
                    assistantState = AssistantState.ERROR,
                    statusDetail = "Voice Input Issue",
                    errorMessage = message,
                    partialTranscript = "",
                    rmsDb = 0f
                )
            }
        },
        onTtsReadyChanged = { ready ->
            _uiState.update { it.copy(isTtsReady = ready) }
        },
        onSpeakingStarted = {
            _uiState.update {
                it.copy(
                    assistantState = AssistantState.SPEAKING,
                    statusDetail = "Speaking Response"
                )
            }
        },
        onSpeakingFinished = {
            _uiState.update { state ->
                if (state.assistantState == AssistantState.SPEAKING) {
                    state.copy(
                        assistantState = AssistantState.STANDBY,
                        statusDetail = "System Ready"
                    )
                } else {
                    state
                }
            }
        }
    )

    init {
        val recognitionAvailable = voiceEngine.isRecognitionAvailable
        _uiState.update {
            it.copy(
                isSpeechRecognitionAvailable = recognitionAvailable,
                statusDetail = if (recognitionAvailable) "System Ready" else "Text Input Ready"
            )
        }
    }

    fun updateMicPermission(granted: Boolean) {
        _uiState.update {
            it.copy(
                hasMicPermission = granted,
                errorMessage = if (granted) null else it.errorMessage,
                statusDetail = if (granted && it.assistantState == AssistantState.ERROR) {
                    "System Ready"
                } else {
                    it.statusDetail
                },
                assistantState = if (granted && it.assistantState == AssistantState.ERROR) {
                    AssistantState.STANDBY
                } else {
                    it.assistantState
                }
            )
        }
    }

    fun onMicPermissionDenied(permanentlyDenied: Boolean) {
        val message = if (permanentlyDenied) {
            "Microphone permission is denied. Enable it in App Settings to use voice commands, or type below."
        } else {
            "Microphone access was denied. Grant permission to use voice input, or type your command below."
        }
        _uiState.update {
            it.copy(
                hasMicPermission = false,
                assistantState = AssistantState.ERROR,
                statusDetail = "Microphone Permission Denied",
                errorMessage = message
            )
        }
    }

    fun onInputTextChanged(text: String) {
        _uiState.update { it.copy(inputText = text) }
    }

    fun onMicButtonPressed(requestPermission: () -> Unit) {
        val current = _uiState.value
        when {
            !current.hasMicPermission -> {
                requestPermission()
            }
            current.assistantState == AssistantState.LISTENING -> {
                voiceEngine.stopListening()
                _uiState.update {
                    it.copy(
                        assistantState = AssistantState.STANDBY,
                        statusDetail = "System Ready",
                        partialTranscript = "",
                        rmsDb = 0f
                    )
                }
            }
            current.assistantState == AssistantState.SPEAKING -> {
                voiceEngine.stopSpeaking()
            }
            !current.isSpeechRecognitionAvailable -> {
                _uiState.update {
                    it.copy(
                        assistantState = AssistantState.ERROR,
                        statusDetail = "Speech Recognizer Unavailable",
                        errorMessage = "No Android speech recognition service was found. Use the text input below."
                    )
                }
            }
            else -> {
                voiceEngine.startListening(current.settings.language)
            }
        }
    }

    fun sendTypedMessage() {
        val text = _uiState.value.inputText.trim()
        if (text.isEmpty()) return
        _uiState.update { it.copy(inputText = "") }
        submitUserCommand(text)
    }

    fun submitUserCommand(text: String) {
        val cleanText = text.trim()
        if (cleanText.isEmpty()) return

        voiceEngine.stopSpeaking()
        thinkingJob?.cancel()

        val currentSettings = _uiState.value.settings
        val userMessage = ChatMessage(
            sender = MessageSender.USER,
            text = cleanText,
            languageTag = currentSettings.language.tag
        )

        val updatedWithUser = _uiState.value.messages + userMessage
        storage.saveMessages(updatedWithUser)

        _uiState.update {
            it.copy(
                messages = updatedWithUser,
                assistantState = AssistantState.THINKING,
                statusDetail = "Processing Command",
                errorMessage = null
            )
        }

        thinkingJob = viewModelScope.launch {
            delay(320L)
            val response = commandHandler.processCommand(
                rawInput = cleanText,
                language = currentSettings.language
            )

            val jarvisMessage = ChatMessage(
                sender = MessageSender.JARVIS,
                text = response.reply,
                languageTag = currentSettings.language.tag
            )

            val nextMessages = if (response.clearConversation) {
                storage.clearMessages()
                listOf(jarvisMessage)
            } else {
                (_uiState.value.messages + jarvisMessage).also {
                    storage.saveMessages(it)
                }
            }

            _uiState.update {
                it.copy(
                    messages = nextMessages,
                    assistantState = if (currentSettings.voiceOutputEnabled && it.isTtsReady) {
                        AssistantState.SPEAKING
                    } else {
                        AssistantState.STANDBY
                    },
                    statusDetail = if (currentSettings.voiceOutputEnabled && it.isTtsReady) {
                        "Speaking Response"
                    } else {
                        "System Ready"
                    }
                )
            }

            if (currentSettings.voiceOutputEnabled && _uiState.value.isTtsReady) {
                voiceEngine.speak(
                    text = response.reply,
                    language = currentSettings.language,
                    speechRate = currentSettings.speechRate
                )
            }
        }
    }

    fun setLanguage(language: JarvisLanguage) {
        val nextSettings = _uiState.value.settings.copy(language = language)
        storage.saveSettings(nextSettings)
        voiceEngine.applyTtsLanguage(language)
        _uiState.update {
            it.copy(
                settings = nextSettings,
                statusDetail = "Language: ${language.displayName}"
            )
        }
    }

    fun setVoiceOutputEnabled(enabled: Boolean) {
        val nextSettings = _uiState.value.settings.copy(voiceOutputEnabled = enabled)
        storage.saveSettings(nextSettings)
        if (!enabled) {
            voiceEngine.stopSpeaking()
        }
        _uiState.update { it.copy(settings = nextSettings) }
    }

    fun setSpeechRate(rate: Float) {
        val clamped = rate.coerceIn(0.7f, 1.4f)
        val nextSettings = _uiState.value.settings.copy(speechRate = clamped)
        storage.saveSettings(nextSettings)
        voiceEngine.setSpeechRate(clamped)
        _uiState.update { it.copy(settings = nextSettings) }
    }

    fun clearConversation() {
        voiceEngine.stopSpeaking()
        thinkingJob?.cancel()
        storage.clearMessages()
        _uiState.update {
            it.copy(
                messages = emptyList(),
                assistantState = AssistantState.STANDBY,
                statusDetail = "Conversation Cleared",
                errorMessage = null
            )
        }
    }

    fun dismissError() {
        _uiState.update {
            it.copy(
                errorMessage = null,
                assistantState = AssistantState.STANDBY,
                statusDetail = "System Ready"
            )
        }
    }

    override fun onCleared() {
        super.onCleared()
        thinkingJob?.cancel()
        voiceEngine.release()
    }
}
