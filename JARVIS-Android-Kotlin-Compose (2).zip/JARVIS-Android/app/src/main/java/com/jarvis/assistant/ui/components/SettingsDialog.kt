package com.jarvis.assistant.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jarvis.assistant.model.JarvisLanguage
import com.jarvis.assistant.model.JarvisSettings
import com.jarvis.assistant.ui.theme.JarvisColors
import java.util.Locale

@Composable
fun SettingsDialog(
    settings: JarvisSettings,
    onLanguageSelected: (JarvisLanguage) -> Unit,
    onVoiceOutputToggled: (Boolean) -> Unit,
    onSpeechRateChanged: (Float) -> Unit,
    onClearHistory: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = JarvisColors.DeepNavy,
        titleContentColor = JarvisColors.TextPrimary,
        textContentColor = JarvisColors.TextSecondary,
        shape = RoundedCornerShape(20.dp),
        title = {
            Text(
                text = "JARVIS Settings",
                fontWeight = FontWeight.SemiBold,
                fontSize = 18.sp
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Voice & Command Language",
                        color = JarvisColors.TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        JarvisLanguage.entries.forEach { lang ->
                            val selected = settings.language == lang
                            OutlinedButton(
                                onClick = { onLanguageSelected(lang) },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(
                                    width = 1.dp,
                                    color = if (selected) JarvisColors.ElectricBlue else JarvisColors.HairlineBorder
                                ),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    containerColor = if (selected) {
                                        JarvisColors.ElectricBlue.copy(alpha = 0.16f)
                                    } else {
                                        JarvisColors.SurfaceNavy
                                    },
                                    contentColor = if (selected) {
                                        JarvisColors.ElectricBlue
                                    } else {
                                        JarvisColors.TextSecondary
                                    }
                                )
                            ) {
                                Text(
                                    text = if (lang == JarvisLanguage.ENGLISH) "English" else "Hindi",
                                    fontSize = 13.sp,
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
                        Text(
                            text = "Spoken Responses",
                            color = JarvisColors.TextPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = "Speak answers aloud with Text-to-Speech",
                            color = JarvisColors.TextSecondary,
                            fontSize = 12.sp
                        )
                    }
                    Switch(
                        checked = settings.voiceOutputEnabled,
                        onCheckedChange = onVoiceOutputToggled,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = JarvisColors.DeepBlack,
                            checkedTrackColor = JarvisColors.ElectricBlue
                        )
                    )
                }

                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Speech Rate",
                            color = JarvisColors.TextPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = String.format(Locale.US, "%.1fx", settings.speechRate),
                            color = JarvisColors.ElectricBlue,
                            fontSize = 13.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Slider(
                        value = settings.speechRate,
                        onValueChange = onSpeechRateChanged,
                        valueRange = 0.7f..1.4f,
                        colors = SliderDefaults.colors(
                            thumbColor = JarvisColors.ElectricBlue,
                            activeTrackColor = JarvisColors.ElectricBlue,
                            inactiveTrackColor = JarvisColors.SurfaceElevated
                        )
                    )
                }

                OutlinedButton(
                    onClick = {
                        onClearHistory()
                        onDismiss()
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, JarvisColors.ErrorCoral.copy(alpha = 0.45f)),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = JarvisColors.ErrorCoral
                    )
                ) {
                    Text("Clear Conversation History")
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Done", color = JarvisColors.ElectricBlue)
            }
        }
    )
}
