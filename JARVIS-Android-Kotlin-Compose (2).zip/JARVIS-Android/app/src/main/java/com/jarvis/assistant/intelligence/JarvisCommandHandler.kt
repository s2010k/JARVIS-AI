package com.jarvis.assistant.intelligence

import com.jarvis.assistant.model.JarvisLanguage
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

data class CommandResponse(
    val reply: String,
    val clearConversation: Boolean = false
)

class JarvisCommandHandler {

    fun processCommand(
        rawInput: String,
        language: JarvisLanguage,
        now: ZonedDateTime = ZonedDateTime.now()
    ): CommandResponse {
        val normalized = rawInput.trim()
            .lowercase(Locale.ROOT)
            .replace(Regex("[?!.,।]+$"), "")
            .trim()

        if (normalized.isEmpty()) {
            return CommandResponse(
                reply = if (language == JarvisLanguage.HINDI) {
                    "मैं सुन रहा हूँ। कृपया कोई कमांड बोलें या टाइप करें।"
                } else {
                    "I am listening. Please speak or type a command."
                }
            )
        }

        // Clear conversation commands
        if (normalized in setOf("clear conversation", "clear history", "reset chat", "clear chat") ||
            normalized.contains("चैट साफ") || normalized.contains("हिस्ट्री हटाओ")
        ) {
            return CommandResponse(
                reply = if (language == JarvisLanguage.HINDI) {
                    "बातचीत का इतिहास साफ कर दिया गया है।"
                } else {
                    "Conversation history cleared."
                },
                clearConversation = true
            )
        }

        // Greeting commands
        if (normalized == "hello jarvis" ||
            normalized == "hi jarvis" ||
            normalized == "hey jarvis" ||
            normalized == "hello" ||
            normalized == "hi" ||
            normalized.contains("नमस्ते") ||
            normalized.contains("हेलो जार्विस") ||
            normalized.contains("हाय जार्विस")
        ) {
            return CommandResponse(
                reply = if (language == JarvisLanguage.HINDI) {
                    "नमस्ते। मैं आपकी क्या सहायता कर सकता हूँ?"
                } else {
                    "Hello. How can I help?"
                }
            )
        }

        // Time commands
        if (normalized.contains("what time is it") ||
            normalized.contains("current time") ||
            normalized == "time" ||
            normalized.contains("tell me the time") ||
            normalized.contains("समय") ||
            normalized.contains("कितने बजे") ||
            normalized.contains("टाइम क्या")
        ) {
            val formattedTime = now.format(DateTimeFormatter.ofPattern("h:mm a", Locale.ENGLISH))
            return CommandResponse(
                reply = if (language == JarvisLanguage.HINDI) {
                    "अभी समय $formattedTime हुआ है।"
                } else {
                    "The current time is $formattedTime."
                }
            )
        }

        // Date commands
        if (normalized.contains("today's date") ||
            normalized.contains("todays date") ||
            normalized.contains("what is the date") ||
            normalized.contains("what date is it") ||
            normalized == "date" ||
            normalized.contains("तारीख") ||
            normalized.contains("आज की डेट") ||
            normalized.contains("आज कौन सा दिन")
        ) {
            val reply = if (language == JarvisLanguage.HINDI) {
                val hindiLocale = Locale("hi", "IN")
                val formattedDate = now.format(DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy", hindiLocale))
                "आज $formattedDate है।"
            } else {
                val formattedDate = now.format(DateTimeFormatter.ofPattern("EEEE, MMMM d, yyyy", Locale.ENGLISH))
                "Today's date is $formattedDate."
            }
            return CommandResponse(reply = reply)
        }

        // Identity & capabilities
        if (normalized.contains("who are you") ||
            normalized.contains("what is your name") ||
            normalized.contains("तुम कौन हो") ||
            normalized.contains("आपका नाम")
        ) {
            return CommandResponse(
                reply = if (language == JarvisLanguage.HINDI) {
                    "मैं जार्विस हूँ, आपका व्यक्तिगत वॉइस और कमांड असिस्टेंट।"
                } else {
                    "I am JARVIS, your personal voice and command assistant."
                }
            )
        }

        // Status / check-in
        if (normalized.contains("how are you") ||
            normalized.contains("system status") ||
            normalized.contains("कैसे हो") ||
            normalized.contains("सिस्टम स्टेटस")
        ) {
            return CommandResponse(
                reply = if (language == JarvisLanguage.HINDI) {
                    "सभी लोकल सिस्टम सामान्य रूप से काम कर रहे हैं। मैं मदद के लिए तैयार हूँ।"
                } else {
                    "All local systems are operating normally. I am ready to assist you."
                }
            )
        }

        // Help / supported commands
        if (normalized == "help" ||
            normalized.contains("what can you do") ||
            normalized.contains("commands") ||
            normalized.contains("मदद") ||
            normalized.contains("क्या कर सकते हो")
        ) {
            return CommandResponse(
                reply = if (language == JarvisLanguage.HINDI) {
                    "आप मुझसे कह सकते हैं: 'नमस्ते जार्विस', 'अभी समय क्या है', 'आज की तारीख क्या है', 'सिस्टम स्टेटस', या 'हिस्ट्री हटाओ'।"
                } else {
                    "You can try: 'Hello Jarvis', 'What time is it?', 'What is today's date?', 'System status', or 'Clear conversation'."
                }
            )
        }

        // Gratitude
        if (normalized.contains("thank you") ||
            normalized == "thanks" ||
            normalized.contains("धन्यवाद") ||
            normalized.contains("शुक्रिया")
        ) {
            return CommandResponse(
                reply = if (language == JarvisLanguage.HINDI) {
                    "आपका स्वागत है। जब भी जरूरत हो मुझे बताएं।"
                } else {
                    "You are welcome. Let me know whenever you need assistance."
                }
            )
        }

        // Helpful fallback for unknown commands
        return CommandResponse(
            reply = if (language == JarvisLanguage.HINDI) {
                "मैंने सुना: \"$rawInput\"। मैं अभी लोकल ऑफलाइन कमांड हैंडल करता हूँ। समय, तारीख या मदद के लिए पूछें।"
            } else {
                "I heard \"$rawInput\", though I do not have a local handler for that yet. Try asking 'What time is it?', 'What is today's date?', or 'Help'."
            }
        )
    }
}
