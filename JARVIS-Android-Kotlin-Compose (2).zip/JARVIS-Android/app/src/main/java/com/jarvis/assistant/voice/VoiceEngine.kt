package com.jarvis.assistant.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.jarvis.assistant.model.JarvisLanguage
import java.util.Locale
import java.util.UUID

class VoiceEngine(
    private val context: Context,
    private val onListeningStarted: () -> Unit,
    private val onPartialResult: (String) -> Unit,
    private val onFinalResult: (String) -> Unit,
    private val onRmsChanged: (Float) -> Unit,
    private val onSpeechError: (String) -> Unit,
    private val onTtsReadyChanged: (Boolean) -> Unit,
    private val onSpeakingStarted: () -> Unit,
    private val onSpeakingFinished: () -> Unit
) {
    private val mainHandler = Handler(Looper.getMainLooper())
    private var speechRecognizer: SpeechRecognizer? = null
    private var textToSpeech: TextToSpeech? = null
    private var ttsInitialized = false
    private var currentLanguage = JarvisLanguage.ENGLISH

    val isRecognitionAvailable: Boolean
        get() = SpeechRecognizer.isRecognitionAvailable(context)

    init {
        initTextToSpeech()
    }

    private fun initTextToSpeech() {
        textToSpeech = TextToSpeech(context) { status ->
            mainHandler.post {
                if (status == TextToSpeech.SUCCESS) {
                    ttsInitialized = true
                    applyTtsLanguage(currentLanguage)
                    onTtsReadyChanged(true)
                } else {
                    ttsInitialized = false
                    onTtsReadyChanged(false)
                }
            }
        }

        textToSpeech?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                mainHandler.post { onSpeakingStarted() }
            }

            override fun onDone(utteranceId: String?) {
                mainHandler.post { onSpeakingFinished() }
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                mainHandler.post { onSpeakingFinished() }
            }

            override fun onError(utteranceId: String?, errorCode: Int) {
                mainHandler.post { onSpeakingFinished() }
            }
        })
    }

    fun applyTtsLanguage(language: JarvisLanguage): Boolean {
        currentLanguage = language
        val tts = textToSpeech ?: return false
        if (!ttsInitialized) return false

        val result = tts.setLanguage(language.locale)
        return if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            tts.setLanguage(Locale.US)
            false
        } else {
            true
        }
    }

    fun setSpeechRate(rate: Float) {
        textToSpeech?.setSpeechRate(rate.coerceIn(0.6f, 1.5f))
    }

    fun speak(text: String, language: JarvisLanguage, speechRate: Float) {
        mainHandler.post {
            val tts = textToSpeech
            if (!ttsInitialized || tts == null) {
                onSpeakingFinished()
                return@post
            }
            applyTtsLanguage(language)
            tts.setSpeechRate(speechRate.coerceIn(0.6f, 1.5f))
            val utteranceId = UUID.randomUUID().toString()
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
        }
    }

    fun stopSpeaking() {
        mainHandler.post {
            textToSpeech?.stop()
            onSpeakingFinished()
        }
    }

    fun startListening(language: JarvisLanguage) {
        mainHandler.post {
            if (!isRecognitionAvailable) {
                onSpeechError("Speech recognition service is not available on this device.")
                return@post
            }

            stopSpeaking()
            destroyRecognizer()

            val recognizer = SpeechRecognizer.createSpeechRecognizer(context)
            speechRecognizer = recognizer

            recognizer.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    onListeningStarted()
                }

                override fun onBeginningOfSpeech() {}

                override fun onRmsChanged(rmsdB: Float) {
                    onRmsChanged(rmsdB)
                }

                override fun onBufferReceived(buffer: ByteArray?) {}

                override fun onEndOfSpeech() {
                    onRmsChanged(0f)
                }

                override fun onError(error: Int) {
                    onRmsChanged(0f)
                    onSpeechError(mapSpeechError(error))
                }

                override fun onResults(results: Bundle?) {
                    onRmsChanged(0f)
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val bestMatch = matches?.firstOrNull()?.trim().orEmpty()
                    if (bestMatch.isNotEmpty()) {
                        onFinalResult(bestMatch)
                    } else {
                        onSpeechError("No speech detected. Tap the microphone to try again.")
                    }
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    val partial = partialResults
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()
                        ?.trim()
                        .orEmpty()
                    if (partial.isNotEmpty()) {
                        onPartialResult(partial)
                    }
                }

                override fun onEvent(eventType: Int, params: Bundle?) {}
            })

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(
                    RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                    RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
                )
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, language.tag)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, language.tag)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            }

            try {
                recognizer.startListening(intent)
            } catch (e: SecurityException) {
                onSpeechError("Microphone permission is required to listen.")
            } catch (e: Exception) {
                onSpeechError(e.localizedMessage ?: "Unable to start speech recognition.")
            }
        }
    }

    fun stopListening() {
        mainHandler.post {
            speechRecognizer?.stopListening()
            onRmsChanged(0f)
        }
    }

    fun cancelListening() {
        mainHandler.post {
            speechRecognizer?.cancel()
            onRmsChanged(0f)
        }
    }

    private fun destroyRecognizer() {
        speechRecognizer?.destroy()
        speechRecognizer = null
    }

    fun release() {
        mainHandler.post {
            destroyRecognizer()
            textToSpeech?.stop()
            textToSpeech?.shutdown()
            textToSpeech = null
            ttsInitialized = false
        }
    }

    private fun mapSpeechError(errorCode: Int): String {
        return when (errorCode) {
            SpeechRecognizer.ERROR_AUDIO -> "Audio recording error."
            SpeechRecognizer.ERROR_CLIENT -> "Speech recognizer cancelled."
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission is required."
            SpeechRecognizer.ERROR_NETWORK,
            SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Network unavailable for online speech recognition."
            SpeechRecognizer.ERROR_NO_MATCH -> "I could not catch that clearly. Please try again."
            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Speech recognizer is busy. Try again in a moment."
            SpeechRecognizer.ERROR_SERVER -> "Speech recognition server error."
            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No speech input detected."
            else -> "Speech recognition error ($errorCode)."
        }
    }
}
