package com.jarvis.assistant.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

object JarvisColors {
    val DeepBlack = Color(0xFF030712)
    val DeepNavy = Color(0xFF070E20)
    val SurfaceNavy = Color(0xFF0C1730)
    val SurfaceElevated = Color(0xFF112042)
    val ElectricBlue = Color(0xFF00D4FF)
    val CyanGlow = Color(0xFF38BDF8)
    val ArcCoreWhite = Color(0xFFE0F7FF)
    val ThinkingAmber = Color(0xFFF59E0B)
    val ErrorCoral = Color(0xFFF87171)
    val TextPrimary = Color(0xFFF1F5F9)
    val TextSecondary = Color(0xFF94A3B8)
    val HairlineBorder = Color(0x3300D4FF)
}

private val JarvisDarkColorScheme = darkColorScheme(
    primary = JarvisColors.ElectricBlue,
    onPrimary = JarvisColors.DeepBlack,
    secondary = JarvisColors.CyanGlow,
    onSecondary = JarvisColors.DeepBlack,
    background = JarvisColors.DeepBlack,
    onBackground = JarvisColors.TextPrimary,
    surface = JarvisColors.DeepNavy,
    onSurface = JarvisColors.TextPrimary,
    surfaceVariant = JarvisColors.SurfaceNavy,
    onSurfaceVariant = JarvisColors.TextSecondary,
    error = JarvisColors.ErrorCoral,
    outline = JarvisColors.HairlineBorder
)

private val JarvisTypography = Typography(
    headlineMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 24.sp,
        letterSpacing = 3.sp
    ),
    titleMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 15.sp,
        letterSpacing = 0.5.sp
    ),
    bodyMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 14.sp,
        lineHeight = 20.sp
    ),
    labelMedium = TextStyle(
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.Medium,
        fontSize = 12.sp,
        letterSpacing = 0.8.sp
    )
)

@Composable
fun JarvisTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = JarvisDarkColorScheme,
        typography = JarvisTypography,
        content = content
    )
}
