package com.jarvis.assistant.data

import android.content.Context
import com.jarvis.assistant.model.ChatMessage
import com.jarvis.assistant.model.JarvisLanguage
import com.jarvis.assistant.model.JarvisSettings
import com.jarvis.assistant.model.MessageSender
import org.json.JSONArray
import org.json.JSONObject

class JarvisStorage(context: Context) {

    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun loadSettings(): JarvisSettings {
        val langTag = prefs.getString(KEY_LANGUAGE, JarvisLanguage.ENGLISH.tag)
            ?: JarvisLanguage.ENGLISH.tag
        val voiceEnabled = prefs.getBoolean(KEY_VOICE_ENABLED, true)
        val speechRate = prefs.getFloat(KEY_SPEECH_RATE, 1.0f).coerceIn(0.6f, 1.5f)
        return JarvisSettings(
            language = JarvisLanguage.fromTag(langTag),
            voiceOutputEnabled = voiceEnabled,
            speechRate = speechRate
        )
    }

    fun saveSettings(settings: JarvisSettings) {
        prefs.edit()
            .putString(KEY_LANGUAGE, settings.language.tag)
            .putBoolean(KEY_VOICE_ENABLED, settings.voiceOutputEnabled)
            .putFloat(KEY_SPEECH_RATE, settings.speechRate)
            .apply()
    }

    fun loadMessages(): List<ChatMessage> {
        val raw = prefs.getString(KEY_MESSAGES, null) ?: return emptyList()
        return try {
            val array = JSONArray(raw)
            buildList {
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    val senderName = obj.optString("sender", MessageSender.JARVIS.name)
                    val sender = runCatching { MessageSender.valueOf(senderName) }
                        .getOrDefault(MessageSender.JARVIS)
                    add(
                        ChatMessage(
                            id = obj.optString("id"),
                            sender = sender,
                            text = obj.optString("text"),
                            timestampMillis = obj.optLong("timestampMillis", System.currentTimeMillis()),
                            languageTag = obj.optString("languageTag", JarvisLanguage.ENGLISH.tag)
                        )
                    )
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun saveMessages(messages: List<ChatMessage>) {
        val array = JSONArray()
        messages.takeLast(MAX_STORED_MESSAGES).forEach { message ->
            val obj = JSONObject().apply {
                put("id", message.id)
                put("sender", message.sender.name)
                put("text", message.text)
                put("timestampMillis", message.timestampMillis)
                put("languageTag", message.languageTag)
            }
            array.put(obj)
        }
        prefs.edit().putString(KEY_MESSAGES, array.toString()).apply()
    }

    fun clearMessages() {
        prefs.edit().remove(KEY_MESSAGES).apply()
    }

    private companion object {
        const val PREFS_NAME = "jarvis_local_storage"
        const val KEY_LANGUAGE = "language_tag"
        const val KEY_VOICE_ENABLED = "voice_output_enabled"
        const val KEY_SPEECH_RATE = "speech_rate"
        const val KEY_MESSAGES = "conversation_messages_json"
        const val MAX_STORED_MESSAGES = 100
    }
}
