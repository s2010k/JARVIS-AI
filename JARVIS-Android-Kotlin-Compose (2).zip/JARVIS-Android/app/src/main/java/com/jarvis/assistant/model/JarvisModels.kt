package com.jarvis.assistant.model

import java.util.Locale
import java.util.UUID

enum class AssistantState(val label: String) {
    STANDBY("Standby"),
    LISTENING("Listening"),
    THINKING("Thinking"),
    SPEAKING("Speaking"),
    ERROR("Attention Required")
}

enum class JarvisLanguage(
    val displayName: String,
    val tag: String,
    val locale: Locale
) {
    ENGLISH("English (US)", "en-US", Locale.US),
    HINDI("Hindi (हिन्दी)", "hi-IN", Locale("hi", "IN"));

    companion object {
        fun fromTag(tag: String): JarvisLanguage {
            return entries.firstOrNull { it.tag == tag } ?: ENGLISH
        }
    }
}

enum class MessageSender {
    USER,
    JARVIS
}

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val sender: MessageSender,
    val text: String,
    val timestampMillis: Long = System.currentTimeMillis(),
    val languageTag: String = JarvisLanguage.ENGLISH.tag
)

data class JarvisSettings(
    val language: JarvisLanguage = JarvisLanguage.ENGLISH,
    val voiceOutputEnabled: Boolean = true,
    val speechRate: Float = 1.0f
)

data class JarvisUiState(
    val assistantState: AssistantState = AssistantState.STANDBY,
    val messages: List<ChatMessage> = emptyList(),
    val inputText: String = "",
    val settings: JarvisSettings = JarvisSettings(),
    val hasMicPermission: Boolean = false,
    val isSpeechRecognitionAvailable: Boolean = true,
    val isTtsReady: Boolean = false,
    val rmsDb: Float = 0f,
    val partialTranscript: String = "",
    val errorMessage: String? = null,
    val statusDetail: String = "System Ready"
)
