package com.jarvis.assistant.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.HourglassTop
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jarvis.assistant.model.AssistantState
import com.jarvis.assistant.model.ChatMessage
import com.jarvis.assistant.model.JarvisLanguage
import com.jarvis.assistant.model.JarvisUiState
import com.jarvis.assistant.model.MessageSender
import com.jarvis.assistant.ui.components.ArcReactorCore
import com.jarvis.assistant.ui.components.SettingsDialog
import com.jarvis.assistant.ui.theme.JarvisColors
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun JarvisHomeScreen(
    uiState: JarvisUiState,
    onMicClick: () -> Unit,
    onInputTextChanged: (String) -> Unit,
    onSendClick: () -> Unit,
    onQuickCommand: (String) -> Unit,
    onClearConversation: () -> Unit,
    onLanguageSelected: (JarvisLanguage) -> Unit,
    onVoiceOutputToggled: (Boolean) -> Unit,
    onSpeechRateChanged: (Float) -> Unit,
    onDismissError: () -> Unit,
    onOpenAppSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showSettings by rememberSaveable { mutableStateOf(false) }
    val listState = rememberLazyListState()

    LaunchedEffect(uiState.messages.size) {
        if (uiState.messages.isNotEmpty()) {
            listState.animateScrollToItem(uiState.messages.lastIndex)
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        JarvisColors.DeepBlack,
                        JarvisColors.DeepNavy,
                        JarvisColors.DeepBlack
                    )
                )
            )
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // 1. JARVIS Title, System Status, Clear & Settings Controls
            TopHudHeader(
                assistantState = uiState.assistantState,
                statusDetail = uiState.statusDetail,
                language = uiState.settings.language,
                hasMessages = uiState.messages.isNotEmpty(),
                onClearClick = onClearConversation,
                onSettingsClick = { showSettings = true }
            )

            // Permission / Error Banner when needed
            if (uiState.errorMessage != null) {
                ErrorBanner(
                    message = uiState.errorMessage,
                    showAppSettingsAction = !uiState.hasMicPermission,
                    onOpenSettings = onOpenAppSettings,
                    onDismiss = onDismissError
                )
            }

            // 2. & 3. Large Animated Circular AI Core + Central Microphone Button
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                ArcReactorCore(
                    assistantState = uiState.assistantState,
                    rmsDb = uiState.rmsDb,
                    hasMicPermission = uiState.hasMicPermission,
                    onMicClick = onMicClick,
                    diameter = 212.dp
                )

                Spacer(modifier = Modifier.height(8.dp))

                // 4. Listening, Thinking and Speaking Indicators
                AssistantStateIndicatorRow(
                    assistantState = uiState.assistantState,
                    partialTranscript = uiState.partialTranscript
                )
            }

            // 5. Conversation History Panel
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                shape = RoundedCornerShape(20.dp),
                color = JarvisColors.SurfaceNavy.copy(alpha = 0.72f),
                border = BorderStroke(1.dp, JarvisColors.HairlineBorder)
            ) {
                if (uiState.messages.isEmpty()) {
                    EmptyConversationState(
                        language = uiState.settings.language,
                        onQuickCommand = onQuickCommand
                    )
                } else {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(uiState.messages, key = { it.id }) { message ->
                            MessageBubble(message = message)
                        }
                    }
                }
            }

            // 6. Text Input and Send Button
            CommandInputBar(
                value = uiState.inputText,
                isThinking = uiState.assistantState == AssistantState.THINKING,
                onValueChange = onInputTextChanged,
                onSendClick = onSendClick
            )
        }
    }

    if (showSettings) {
        SettingsDialog(
            settings = uiState.settings,
            onLanguageSelected = onLanguageSelected,
            onVoiceOutputToggled = onVoiceOutputToggled,
            onSpeechRateChanged = onSpeechRateChanged,
            onClearHistory = onClearConversation,
            onDismiss = { showSettings = false }
        )
    }
}

@Composable
private fun TopHudHeader(
    assistantState: AssistantState,
    statusDetail: String,
    language: JarvisLanguage,
    hasMessages: Boolean,
    onClearClick: () -> Unit,
    onSettingsClick: () -> Unit
) {
    val statusColor = when (assistantState) {
        AssistantState.LISTENING -> JarvisColors.ElectricBlue
        AssistantState.THINKING -> JarvisColors.ThinkingAmber
        AssistantState.SPEAKING -> JarvisColors.CyanGlow
        AssistantState.ERROR -> JarvisColors.ErrorCoral
        AssistantState.STANDBY -> JarvisColors.ElectricBlue
    }

    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = "JARVIS",
                style = MaterialTheme.typography.headlineMedium,
                color = JarvisColors.TextPrimary
            )
            Text(
                text = "$statusDetail · ${if (language == JarvisLanguage.ENGLISH) "EN" else "HI"}",
                style = MaterialTheme.typography.labelMedium,
                color = statusColor,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(
                onClick = onClearClick,
                enabled = hasMessages
            ) {
                Icon(
                    imageVector = Icons.Rounded.DeleteOutline,
                    contentDescription = "Clear conversation",
                    tint = if (hasMessages) JarvisColors.TextSecondary else JarvisColors.TextSecondary.copy(alpha = 0.35f)
                )
            }
            IconButton(onClick = onSettingsClick) {
                Icon(
                    imageVector = Icons.Rounded.Settings,
                    contentDescription = "Open settings",
                    tint = JarvisColors.ElectricBlue
                )
            }
        }
    }
}

@Composable
private fun AssistantStateIndicatorRow(
    assistantState: AssistantState,
    partialTranscript: String
) {
    val states = listOf(
        Triple(AssistantState.LISTENING, "Listening", Icons.Rounded.GraphicEq),
        Triple(AssistantState.THINKING, "Thinking", Icons.Rounded.HourglassTop),
        Triple(AssistantState.SPEAKING, "Speaking", Icons.Rounded.VolumeUp)
    )

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            states.forEach { (state, label, icon) ->
                val active = assistantState == state
                val tint = when {
                    !active -> JarvisColors.TextSecondary.copy(alpha = 0.55f)
                    state == AssistantState.THINKING -> JarvisColors.ThinkingAmber
                    else -> JarvisColors.ElectricBlue
                }
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (active) tint.copy(alpha = 0.14f) else Color.Transparent,
                    border = BorderStroke(
                        width = 1.dp,
                        color = if (active) tint.copy(alpha = 0.65f) else JarvisColors.HairlineBorder.copy(alpha = 0.3f)
                    )
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = null,
                            tint = tint,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = label,
                            color = tint,
                            fontSize = 11.sp,
                            fontWeight = if (active) FontWeight.SemiBold else FontWeight.Normal
                        )
                    }
                }
            }
        }

        if (partialTranscript.isNotBlank()) {
            Text(
                text = "\"$partialTranscript\"",
                color = JarvisColors.CyanGlow,
                fontSize = 12.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun ErrorBanner(
    message: String,
    showAppSettingsAction: Boolean,
    onOpenSettings: () -> Unit,
    onDismiss: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = JarvisColors.ErrorCoral.copy(alpha = 0.12f),
        border = BorderStroke(1.dp, JarvisColors.ErrorCoral.copy(alpha = 0.45f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(
                imageVector = Icons.Rounded.ErrorOutline,
                contentDescription = null,
                tint = JarvisColors.ErrorCoral,
                modifier = Modifier.size(20.dp)
            )
            Text(
                text = message,
                color = JarvisColors.TextPrimary,
                fontSize = 12.sp,
                modifier = Modifier.weight(1f)
            )
            if (showAppSettingsAction) {
                TextButton(onClick = onOpenSettings) {
                    Text("Settings", color = JarvisColors.ElectricBlue, fontSize = 12.sp)
                }
            }
            TextButton(onClick = onDismiss) {
                Text("Dismiss", color = JarvisColors.TextSecondary, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun EmptyConversationState(
    language: JarvisLanguage,
    onQuickCommand: (String) -> Unit
) {
    val suggestions = if (language == JarvisLanguage.HINDI) {
        listOf("नमस्ते जार्विस", "अभी समय क्या है?", "आज की तारीख क्या है?")
    } else {
        listOf("Hello Jarvis", "What time is it?", "What is today's date?")
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Awaiting Voice or Text Input",
            color = JarvisColors.TextPrimary,
            fontSize = 15.sp,
            fontWeight = FontWeight.Medium
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = "Tap the central Arc Reactor mic or try a command:",
            color = JarvisColors.TextSecondary,
            fontSize = 12.sp
        )
        Spacer(modifier = Modifier.height(14.dp))
        Column(
            verticalArrangement = Arrangement.spacedBy(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            suggestions.forEach { command ->
                OutlinedButton(
                    onClick = { onQuickCommand(command) },
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, JarvisColors.HairlineBorder),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = JarvisColors.DeepNavy,
                        contentColor = JarvisColors.CyanGlow
                    )
                ) {
                    Text(text = command, fontSize = 13.sp)
                }
            }
        }
    }
}

@Composable
private fun MessageBubble(message: ChatMessage) {
    val isUser = message.sender == MessageSender.USER
    val timeFormat = SimpleDateFormat("h:mm a", Locale.getDefault())
    val formattedTime = timeFormat.format(Date(message.timestampMillis))

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        Surface(
            modifier = Modifier.widthIn(max = 290.dp),
            shape = RoundedCornerShape(16.dp),
            color = if (isUser) {
                JarvisColors.ElectricBlue.copy(alpha = 0.16f)
            } else {
                JarvisColors.SurfaceElevated
            },
            border = BorderStroke(
                width = 1.dp,
                color = if (isUser) {
                    JarvisColors.ElectricBlue.copy(alpha = 0.45f)
                } else {
                    JarvisColors.HairlineBorder
                }
            )
        ) {
            Column(
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isUser) "You" else "JARVIS",
                        color = if (isUser) JarvisColors.CyanGlow else JarvisColors.ElectricBlue,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "· $formattedTime",
                        color = JarvisColors.TextSecondary,
                        fontSize = 11.sp
                    )
                }
                Text(
                    text = message.text,
                    color = JarvisColors.TextPrimary,
                    fontSize = 14.sp,
                    lineHeight = 20.sp
                )
            }
        }
    }
}

@Composable
private fun CommandInputBar(
    value: String,
    isThinking: Boolean,
    onValueChange: (String) -> Unit,
    onSendClick: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            modifier = Modifier.weight(1f),
            placeholder = {
                Text(
                    text = "Ask JARVIS...",
                    color = JarvisColors.TextSecondary,
                    fontSize = 14.sp
                )
            },
            singleLine = true,
            shape = RoundedCornerShape(16.dp),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
            keyboardActions = KeyboardActions(onSend = { onSendClick() }),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = JarvisColors.ElectricBlue,
                unfocusedBorderColor = JarvisColors.HairlineBorder,
                focusedContainerColor = JarvisColors.SurfaceNavy,
                unfocusedContainerColor = JarvisColors.SurfaceNavy,
                focusedTextColor = JarvisColors.TextPrimary,
                unfocusedTextColor = JarvisColors.TextPrimary,
                cursorColor = JarvisColors.ElectricBlue
            )
        )

        Surface(
            modifier = Modifier.size(50.dp),
            shape = CircleShape,
            color = if (value.isNotBlank() && !isThinking) {
                JarvisColors.ElectricBlue
            } else {
                JarvisColors.SurfaceElevated
            },
            border = BorderStroke(1.dp, JarvisColors.HairlineBorder)
        ) {
            IconButton(
                onClick = onSendClick,
                enabled = value.isNotBlank() && !isThinking
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Rounded.Send,
                    contentDescription = "Send message",
                    tint = if (value.isNotBlank() && !isThinking) {
                        JarvisColors.DeepBlack
                    } else {
                        JarvisColors.TextSecondary
                    }
                )
            }
        }
    }
}
