package com.jarvis.assistant.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.HourglassTop
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.MicOff
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.jarvis.assistant.model.AssistantState
import com.jarvis.assistant.ui.theme.JarvisColors
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun ArcReactorCore(
    assistantState: AssistantState,
    rmsDb: Float,
    hasMicPermission: Boolean,
    onMicClick: () -> Unit,
    modifier: Modifier = Modifier,
    diameter: Dp = 232.dp
) {
    val infiniteTransition = rememberInfiniteTransition(label = "arc_reactor")

    val outerRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 16000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "outer_rotation"
    )

    val innerRotation by infiniteTransition.animateFloat(
        initialValue = 360f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 10000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "inner_rotation"
    )

    val pulseProgress by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulse_ring"
    )

    val wavePhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2f * PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1400, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "wave_phase"
    )

    val normalizedRms = ((rmsDb + 2f) / 12f).coerceIn(0f, 1f)
    val animatedEnergy by animateFloatAsState(
        targetValue = when (assistantState) {
            AssistantState.LISTENING -> 0.45f + normalizedRms * 0.55f
            AssistantState.SPEAKING -> 0.65f
            AssistantState.THINKING -> 0.4f
            AssistantState.ERROR -> 0.2f
            AssistantState.STANDBY -> 0.15f
        },
        animationSpec = tween(durationMillis = 180),
        label = "energy"
    )

    val coreColor by animateColorAsState(
        targetValue = when (assistantState) {
            AssistantState.LISTENING -> JarvisColors.ElectricBlue
            AssistantState.THINKING -> JarvisColors.ThinkingAmber
            AssistantState.SPEAKING -> JarvisColors.CyanGlow
            AssistantState.ERROR -> JarvisColors.ErrorCoral
            AssistantState.STANDBY -> JarvisColors.ElectricBlue
        },
        animationSpec = tween(durationMillis = 250),
        label = "core_color"
    )

    val micLabel = when {
        !hasMicPermission -> "Grant microphone permission"
        assistantState == AssistantState.LISTENING -> "Stop listening"
        assistantState == AssistantState.SPEAKING -> "Stop speaking"
        else -> "Activate microphone"
    }

    Box(
        modifier = modifier.size(diameter),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(diameter)) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val maxRadius = size.minDimension / 2f

            // Ambient radial reactor glow
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        coreColor.copy(alpha = 0.24f + animatedEnergy * 0.16f),
                        coreColor.copy(alpha = 0.08f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = maxRadius
                ),
                radius = maxRadius,
                center = center
            )

            // Smooth expanding pulse ring
            val pulseRadius = maxRadius * (0.48f + pulseProgress * 0.46f)
            val pulseAlpha = (1f - pulseProgress) * (0.28f + animatedEnergy * 0.42f)
            drawCircle(
                color = coreColor.copy(alpha = pulseAlpha),
                radius = pulseRadius,
                center = center,
                style = Stroke(width = 2.dp.toPx())
            )

            // Outer rotating segmented holographic ring
            val outerArcRadius = maxRadius * 0.84f
            rotate(degrees = outerRotation, pivot = center) {
                for (i in 0 until 6) {
                    val startAngle = i * 60f + 8f
                    drawArc(
                        color = coreColor.copy(alpha = if (i % 2 == 0) 0.78f else 0.35f),
                        startAngle = startAngle,
                        sweepAngle = 40f,
                        useCenter = false,
                        topLeft = Offset(center.x - outerArcRadius, center.y - outerArcRadius),
                        size = Size(outerArcRadius * 2f, outerArcRadius * 2f),
                        style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
                    )
                }
            }

            // Counter-rotating inner precision ring
            val innerArcRadius = maxRadius * 0.66f
            rotate(degrees = innerRotation, pivot = center) {
                for (i in 0 until 4) {
                    val startAngle = i * 90f + 12f
                    drawArc(
                        color = JarvisColors.ArcCoreWhite.copy(alpha = 0.55f),
                        startAngle = startAngle,
                        sweepAngle = 56f,
                        useCenter = false,
                        topLeft = Offset(center.x - innerArcRadius, center.y - innerArcRadius),
                        size = Size(innerArcRadius * 2f, innerArcRadius * 2f),
                        style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
                    )
                }
            }

            // Radial sound-wave bars around the core
            val waveBaseRadius = maxRadius * 0.50f
            val barCount = 36
            val isActiveWave = assistantState == AssistantState.LISTENING ||
                assistantState == AssistantState.SPEAKING ||
                assistantState == AssistantState.THINKING

            for (i in 0 until barCount) {
                val angleRad = (i * (360f / barCount)) * (PI / 180.0)
                val harmonic = sin(wavePhase + i * 0.55f).toFloat()
                val amplitude = if (isActiveWave) {
                    (0.35f + 0.65f * kotlin.math.abs(harmonic)) * animatedEnergy * 18.dp.toPx()
                } else {
                    (0.25f + 0.25f * kotlin.math.abs(harmonic)) * 4.dp.toPx()
                }

                val start = Offset(
                    x = center.x + (waveBaseRadius * cos(angleRad)).toFloat(),
                    y = center.y + (waveBaseRadius * sin(angleRad)).toFloat()
                )
                val end = Offset(
                    x = center.x + ((waveBaseRadius + amplitude) * cos(angleRad)).toFloat(),
                    y = center.y + ((waveBaseRadius + amplitude) * sin(angleRad)).toFloat()
                )

                drawLine(
                    color = coreColor.copy(alpha = if (isActiveWave) 0.9f else 0.42f),
                    start = start,
                    end = end,
                    strokeWidth = 2.2.dp.toPx(),
                    cap = StrokeCap.Round
                )
            }
        }

        // Central Microphone Button (>= 48dp touch target)
        Box(
            modifier = Modifier
                .size(84.dp)
                .clip(CircleShape)
                .background(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            JarvisColors.SurfaceElevated,
                            JarvisColors.DeepNavy
                        )
                    )
                )
                .border(
                    width = 1.8.dp,
                    color = coreColor.copy(alpha = 0.85f),
                    shape = CircleShape
                )
                .semantics {
                    contentDescription = micLabel
                }
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    role = Role.Button,
                    onClick = onMicClick
                ),
            contentAlignment = Alignment.Center
        ) {
            val icon = when {
                !hasMicPermission -> Icons.Rounded.MicOff
                assistantState == AssistantState.LISTENING -> Icons.Rounded.GraphicEq
                assistantState == AssistantState.THINKING -> Icons.Rounded.HourglassTop
                assistantState == AssistantState.SPEAKING -> Icons.Rounded.VolumeUp
                else -> Icons.Rounded.Mic
            }
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = coreColor,
                modifier = Modifier.size(34.dp)
            )
        }
    }
}
